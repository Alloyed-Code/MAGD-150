function setup() {
  createCanvas(400, 400);
  background(25);
  stroke(200);
  strokeWeight(2);
  stars = 100;
  while(stars > 0){
    point(Math.random() * 400, Math.random() * 400);
    stars-=1;
  }
}

function draw() {
  stroke(100);
  strokeWeight(2);
  fill(150)
  ellipse(200,500,1600,400);
  noStroke();
  
  stroke(60);
  strokeWeight(2);
  line(170,175, 230,175);
  line(175,180, 225,180);
  line(180,185,220,185);
  noStroke();
  
  fill(40);
  triangle(175,160,225, 160, 200, 190)
  
  fill(75);
  sideHeight = 20;
  sideStart = 0.0;
  while(sideStart < sideHeight){
    rect(220 - sideStart, 50 + sideStart, 50, 100);
    sideStart += 1;
  }
  fill(150);
  rect(220,50, 50, 100);
  
  fill(75);
  sideHeight = 20;
  sideStart = 0.0;
  while(sideStart < sideHeight){
    rect(130 + sideStart, 50 + sideStart, 50, 100);
    sideStart += 1;
  }
  
  fill(150);
  rect(130,50, 50, 100);
  
  fill(100);
  engineHeight = 20;
  engineStart = 0.0;
  while(engineStart < engineHeight){
    ellipse(200, 75 + engineStart, 60 - engineStart, 60);
    fill(100-engineStart*2);
    engineStart += 5;
  }
  fill(100);
  engineHeight = 20;
  engineStart = 0.0;
  while(engineStart < engineHeight){
    ellipse(200, 130 + engineStart, 60 - engineStart, 60);
    fill(100-engineStart*2);
    engineStart += 1;
  }
  
  
  fill(200);
  ellipse(200,75,50,50);
  ellipse(200,130,50,50);
  fill(250);
  ellipse(200,75,35,35);
  ellipse(200,130,35,35);
  
  noFill();
  stroke(220);
  strokeWeight(5);
  strokeJoin(BEVEL);
  beginShape();
  vertex(300,325);
  vertex(300, 300);
  vertex(290,275);
  vertex(310, 250);
  vertex(310, 225);
  endShape();
  noStroke();
  
  fill(75);
  rect(250,305,100,50, 25);
  rect(250,325,100,50);
  fill(150);
  strokeWeight(2);
  stroke(50);
  rect(295,349,10,25)
  fill(175)
  rect(260,325,80,10)
}