function setup() {
  createCanvas(400, 600);
  colorMode(RGB,100);
}

let obj = [[Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2],
           [Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2], 
           [Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2], 
           [Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2],
           [Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2],
           [Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2],
           [Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2],
           [Math.floor(Math.random() * 410)-20, 0, 40,80,Math.floor(Math.random() * 10) + 2]];

let perc = 0;
let objfill = [0,0,150,75];
let backfill = [10,10,25,100];
function draw() {
  background(backfill);
  noStroke();
  fill (30,10,30, 100)
  for (let i = 0; i < perc; i++){
    rect(0,550 - 22*i, 400, i)
  }
  fill(objfill[0],objfill[1],objfill[2],objfill[3]);
  for (let i = 0; i < obj.length;i++){
    obj[i][1] += obj[i][4];
    if(obj[i][1] > 600){
      obj[i][1] = 0;
      obj[i][0] = Math.floor(Math.random() * 410)-20;
    }
    else if (obj[i][1] < 0){
      obj[i][1] = 600;
      obj[i][0] = Math.floor(Math.random() * 410)-20;
    }
    rect(obj[i][0],obj[i][1],obj[i][2],obj[i][3]);
  }
  if (keyIsPressed === true){
    if (key == "i")
      perc += .1;
    objfill = [10,10,25,75];
    backfill = [100,100,150,100];
    }
  else{
    objfill = [0,0,150,75];
    backfill = [10,10,25,100];
    if (perc > 0)
      perc -= .1;
  }
}

function mousePressed(){
  for (let i = 0; i < obj.length;i++){
    if (mouseX > obj[i][0] && mouseX < obj[i][0] + obj[i][2]){
      if (mouseY > obj[i][1] && mouseY < obj[i][1] + obj[i][3]){
        obj[i][4] *= -1;
      }
    }
  }
}

