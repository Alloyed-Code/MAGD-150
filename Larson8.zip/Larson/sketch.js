function preload(){
  alloy = loadImage('alloy.png');
  symbol = loadImage('NebulousSymbol.png');
  wallpaper = loadImage('animspaceship.gif');
}



function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 100);
}

function draw() {
  background(50);
  image(wallpaper, 0,0, 400, 300);
  image(alloy, 200-abs(mouseX-200)/2, 300-abs(mouseX-200)/2,abs(mouseX-200),abs(mouseX-200));
  textFont('Helvetica', 50)
  fill(224,92,4,100);
  stroke(0,0,0,100);
  strokeWeight(10);
  text('Go to Space',50,50);
  text('Forge the Future',10,350,400,75);
  image(symbol, mouseX-32, mouseY-32,64,64);
}