function setup() {
  createCanvas(500, 500);
  colorMode(RGB,100);
}

//angle, x, y, angle change, x change, y change, size
let ships = [[0,20,20,0,1,2,1],[90,250,250,1,1,0,0.75],[90,100,100,0.5,2,1,2],[0,450,100,-5,0.5,2,1],[0,200,100,0,0,-0.25,4]];
let asteroids = [[0,20,100,5,2,4,1,10,15],[0,250,250,3,3,-5,1,20,15],[0,250,400,0,-5,2,1,10,10],[0,200,1,1,1,2,1,50,55]];
function draw() {
  let p = 0;
  background(20);
  angleMode(DEGREES)
  for (i=0;i<ships.length;i++){
    ships[i][0] = ships[i][0]+ships[i][3];
    ships[i][1] = wrapHandler(ships[i][1]+ships[i][4]);
    ships[i][2] = wrapHandler(ships[i][2]+ships[i][5]);
    ship(ships[i][1],ships[i][2],ships[i][0],ships[i][6]);
    p++;
  }
  for (i=0;i<asteroids.length;i++){
    asteroids[i][0] = asteroids[i][0]+asteroids[i][3];
    asteroids[i][1] = wrapHandler(asteroids[i][1]+asteroids[i][4]);
    asteroids[i][2] = wrapHandler(asteroids[i][2]+asteroids[i][5]);
    asteroid(asteroids[i][1],asteroids[i][2],asteroids[i][7],asteroids[i][8],asteroids[i][0],asteroids[i][6]);
    p++;
  }
  entityTotal(p);
}


function ship(x,y,angle,size){
  push();
  translate(x,y);
  rotate(angle);
  scale(size);
  fill(250,250,250,100);
  triangle(0,0,-10,18,-20,18);
  triangle(0,0,10,18,20,18);
  triangle(0,-20,-10,20,10,20);
  fill(0,0,0,100)
  rect(-3,0,6,10);
  scale(1);
  rotate(-angle);
  translate(-x,-y);
  pop();
}

function asteroid(x,y,xd,yd,angle,size){
  push();
  translate(x,y);
  rotate(angle);
  scale(size);
  fill(50,50,50,100);
  ellipse(0,0,xd,yd)
  scale(1);
  rotate(-angle);
  translate(-x,-y);
  pop();
}

function entityTotal(p){
  print("Entity total: "+p);
}

function wrapHandler(coord){
  if (coord > 500){
    return coord - 500;
  }
  else if(coord < 0){
    return 500 + coord
  }
  else{
    return coord;
  }
}