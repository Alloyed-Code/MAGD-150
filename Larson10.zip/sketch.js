function setup() {
  createCanvas(600, 600);
  colorMode(RGB,100);
}

let target = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];


let chromosomes = [];
let total = 132; //total population (chromosomes) in a single generation
for (let i = 0; i < total; i++) {
    let c = new c2.Chromosome();
    c.initInteger(target.length, 97, 122);
    chromosomes.push(c);
}

function fitness(chromosome) {
    let score = 0;
    for (let i = 0; i < target.length; i++) {
        if (String.fromCharCode(chromosome.genes[i]) == target[i]) {
            score++;
        }
    }
    chromosome.fitness = score / chromosome.genes.length;
}

let p = new c2.Population(chromosomes, .7, .01, fitness); //crossover rate, mutation rate
p.setCrossover('two_point');
p.setMutation('random');


function draw() {
    background(50);

    let info = p.fitness();
    fill('black');
    textSize(10);

    for (let i = 0; i < p.chromosomes.length; i++) {
        let val = p.chromosomes[i].toString(true);
        text(val, 65 + 150 * Math.floor(i / 44), 50 + 10 * i - 440 * Math.floor(i / 44));
    }

    textSize(20);
    fill('white');
    text("Generation: " + info.generation, 25, 25)
    text('Best Fitness ' + info.bestFitness, 25, 45);
    text('Worst Fitness ' + info.worstFitness, 25, 65);
    text('Average Fitness ' + info.averageFitness, 25, 85);

    let best = info.bestChromosome;

    if (info.bestFitness == 1) {
        stroke(255);
        strokeWeight(5);
        fill(100, 0, 10);
    }

    textSize(40);
    text(best.toString(true), 25, 300);

    noStroke();
    fill(80, 0, 10);
    rect(0, 500, 600, 100);


    if (info.bestFitness != 1) {
        p.reproduction();
    }
}