function setup() {
  createCanvas(500, 500);
  colorMode(RGB,100);
}

let candles = [50, 100, 75, 125, 100, 45, 110];
let candles_state = []
for (i =0; i<candles.length/2; i+= 2){
  candles_state[i] = 0;
  candles_state[i+1] = 1;
}
let flames = []

function draw() {
  background(25);
  print("Flame Count: " + flames.length);
  
  //candles
  noStroke();
  for (i =1; i <= candles.length; i++){
    fill(120,75,3,100);
    rect(i*70-35, candles[i-1], 15,50);
    fill(200,200,90,100);
    ellipse(i*70-28, candles[i-1]-25,10,30);
    fill(250,250,140, 25);
    ellipse(i*70-28, candles[i-1]-25,100,100);
  }
  for(i=0;i < candles.length; i++){
    if (candles[i] > 150){
      candles_state[i] = 0;
    }
    if (candles[i] < 50){
      candles_state[i] = 1;
    }
    if (candles_state[i] == 1){
      candles[i] += 0.5;
    }
    else{
      candles[i] -= 0.5;
    }
  }
  
  //Pumpkin
  fill(30,10,0,100);
  rect(240,200,20,100);
  fill(150,60,5,100);
  ellipse(200,300,175);
  ellipse(300,300,175);
  fill(170,80,5,100);
  triangle(200,245,225,275,175,275);
  triangle(300,245,275,275,325,275);
  fill(200,210,5,100);
  triangle(200,245,225,275,190,275);
  triangle(300,245,275,275,310,275);
  
  fill(170,80,5,100);
  ellipse(250,340,150,30);
  triangle(175,340,200,310,225,340);
  triangle(200,340,225,300,250,340);
  triangle(225,340,250,310,275,340);
  triangle(250,340,275,295,300,340);
  triangle(275,340,300,310,325,340);
  fill(200,210,5,100);
  ellipse(250,340,140,20);
  triangle(180,340,200,310,225,340);
  triangle(210,340,225,300,245,340);
  triangle(225,340,250,310,275,340);
  triangle(255,340,275,295,290,340);
  triangle(275,340,300,310,320,340);
  
  if (mouseX > 0 && mouseX < 500){
    if (mouseY > 0 && mouseY < 500){
      flames.push([int(mouseX),int(mouseY),100]);
    }
  }
  extinguished = [];
  for (i =0; i < flames.length; i++){
    fill(int(230 * (flames[i][2]/100)),int(100* (flames[i][2]/100)),5,100)
    ellipse(flames[i][0],flames[i][1],int(flames[i][2]/5));
    triangle(flames[i][0] + random(int(-flames[i][2]/10,flames[i][2]/10)),flames[i][1] - random(10,flames[i][2]/2), flames[i][0] - flames[i][2]/10, flames[i][1], flames[i][0] + flames[i][2]/10, flames[i][1]);
    flames[i][2] -= 1;
    if (flames[i][2] < 1){
      extinguished.push(i);
    }
  }
  for (i = 0; i < extinguished.length; i++){
    flames.splice(i,1);
    print("Flame extinguished");
  }
}