let b1Pressed = 0;
let b1Expand = 0;

let b2Pressed = 0;
let extremes = 1;

let b3Pressed = 0;

function setup() {
  createCanvas(800, 800);
  colorMode(RGB,100);
}

function draw() {
  background(15,15,20,100);
  
  //side panel
  fill(10,10,15,100);
  strokeWeight(10);
  stroke(75,100,250,100);
  rect(-80,50,250,150 + b1Expand * 50,0,75,15,0);
  
  //bottom panel
  rect(550,650,100,500,50,25,0,0);
  
  //right panel
  rect(650,500,200,500,0);
  
  //middle window
  
  
  rect(200,200,300,300);
  fill(20,20,25,100);
  rect(200,200,300,50);
  
  fill(10,10,15,100);
  rect(250,100,500,300);
  fill(20,20,25,100);
  rect(250,100,500,50);
  rect(720, 120, 10,10);
  
  //button 1
  
  if (b1Pressed == 1 || b1Pressed == 3){
    fill(5,5,15,100);
    stroke(75,100,250,100);
  }
  else if (b1Pressed == 2){
    fill(20,5,5,100);
    stroke(250,75,50);
  }
  else{
    fill(10,10,15,100);
    stroke(75,100,250,100);
  }
  
  strokeWeight(5)
  rect(35,100,75,75,10);
  
  //b1 expanded
  if (b1Pressed == 2 && b1Expand < 11){
    b1Expand += 0.5;
  }
  else if (b1Pressed == 0 && b1Expand > 0){
    b1Expand -= 0.5;
  }
  for (i = 0; i < b1Expand; i++){
    rect(40,200 + i*50,25,25,10);
    rect(80,200 + i*50,25,25,10);
    }
  
  
  //button 2
  
  if (b2Pressed == 0){
    fill(10,10,15,100);
    stroke(75,100,250,100);
    if(extremes > 1){
      extremes -= 0.1;
    }
  }
  else{
    if (extremes < 100)
      extremes += 1;
    fill(20,5,5,100);
    stroke(250,75,50);
  }
  ellipseMode(RADIUS);
  ellipse(600,700,25);
  
  rect(575,800-extremes/1.5,50,extremes/1.5)
  
  
  //button 3
  fill(10,10,15,100);
  stroke(75,100,250,100);
  if(dist(mouseX,mouseY,725,600) < 50){
    stroke(250,75,50);
  }
  strokeWeight(10);
  ellipse(725,600,50);
  
  stroke(75,100,250,100);
  if(keyIsPressed === true && dist(mouseX,mouseY,725,600) < 50){
    if(key == "i"){
    stroke(250,75,50);
      b3Pressed = 1;
    }
  }
  line(725,575,725,580);
  line(725,600,725,625);
  
  noFill();
  strokeWeight(5);
  beginShape();
  vertex(300,275);
  if(b3Pressed == 1){
    vertex(350,275);
    vertex(400,275 + random(-extremes,extremes));
    //vertex(425,275);
    vertex(450,275 + random(-extremes,extremes));
    //vertex(475,275);
    vertex(500,275 + random(-extremes,extremes));
    //vertex(525,275);
    vertex(550,275 + random(-extremes,extremes));
    //vertex(575,275);
    vertex(600,275 + random(-extremes,extremes));
    vertex(650,275);
  }
  vertex(700,275);
  endShape();
  
  b3Pressed = 0;
}

function mousePressed(){
  //button 1
  if (mouseX > 35 && mouseY > 100){
    if (mouseX < 110 && mouseY < 175){
      if (b1Pressed == 0){ 
        b1Pressed = 1;
      }
      else{
        b1Pressed = 3;
      }
    }
  }
  
  //button 2
  if (dist(mouseX,mouseY,600,700) < 25){
    b2Pressed = 1;
  }
}

function mouseReleased(){
  //buton 2 released
  b2Pressed = 0;
}

function mouseClicked(){
  //button 1
  if (mouseX > 35 && mouseY > 100){
    if (mouseX < 110 && mouseY < 175){
      if (b1Pressed == 1){
        b1Pressed = 2;
      }
      else{
        b1Pressed = 0;
      }
    }
  }
}