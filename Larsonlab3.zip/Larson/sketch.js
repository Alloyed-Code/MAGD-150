fr = 30;
r = 50;
g = 50;
b = 50;
Hthreshold = 150;
Lthreshold = 50;
lighten = true;
change = 10;

x1 = 1;
y1 = 1;
speedx1 = 5;
speedy1 = 2;

x2 = 499;
y2 = 125;
speedx2 = -5;
speedy2 = 2;

x3 = 1;
y3 = 499;
speedx3 = 5;
speedy3 = 1.002;

function setup() {
  createCanvas(500, 500);
  colorMode(RGB,100);
  frameRate(fr);
}

function draw() {
  background(150,10);
  noStroke();
  fill(150,0,0,100);
  x1 += speedx1;
  y1 += speedy1;
  if (x1 >=500){
    speedx1 *= -1
  }
  if (x1 <= 0){
    speedx1 *= -1
  }
  if (y1 >= 500){
    speedy1 *= -1
  }
  if (y1 <= 0){
    speedy1 *= -1
  }
  ellipse(x1,y1,25);
  
  
  fill(0,0,150,100);
  x2 += speedx2;
  y2 += speedy2;
  if (x2 >=500){
    speedx2 *= -1
  }
  if (x2 <= 0){
    speedx2 *= -1
  }
  if (y2 >= 500){
    speedy2 *= -1
  }
  if (y2 <= 0){
    speedy2 *= -1
  }
  ellipse(x2,y2,25);
  
  fill(0,150,0,100);
  base = 0.9
  x3 += speedx3;
  y3 *= pow(base,speedy3);
  if (x3 >=500){
    speedx3 *= -1
    speedy3 *= -1
  }
  if (x3 <= 0){
    speedx3 *= -1
    speedy3 *= -1
  }

  //print(y3)
  ellipse(x3,y3,25);
  
  if (lighten)
    if (r > Hthreshold)
      if (g > Hthreshold)
        if (b > Hthreshold)
          lighten = false;
        else
          b += change;
      else
        g += change;
    else
      r += change;
  else
    if (r < Lthreshold)
      if (g < Lthreshold)
        if (b < Lthreshold)
          lighten = true;
        else
          b -= change;
      else
        g -= change;
    else
      r -= change;
  
  stroke(20,20,20,100);
  strokeWeight(2);
  fill(r,g,b,100);
  ellipse(mouseX, mouseY, dist(mouseX,mouseY,pmouseX,pmouseY));
}