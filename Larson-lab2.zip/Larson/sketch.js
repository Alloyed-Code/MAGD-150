function setup() {
  createCanvas(400, 400);
  background(25);
  stroke(200);
  strokeWeight(2);
  stars = 100;
  while(stars > 0){
    point(Math.random() * 400, Math.random() * 400);
    stars-=1;
  }
  colorMode(RGB,255,255,255,100);
}

function draw() {
  
  //planet
  //fill(255,255,255,100);
  //noStroke();
  //ellipse(60,200,10);
  fill(10,10,100,100);
  noStroke();
  ellipse(325,75,540);
  stroke(0,0,50,100);
  noFill();
  strokeWeight(10);
  curve(195,-200,55,50,160,290, 460, 275);
  fill(25,50,100,100);
  noStroke();
  arc(325,75,540,540,QUARTER_PI, HALF_PI + QUARTER_PI, OPEN);
  fill(0,0,40,100);
  arc(325,75,540,540, PI-.2, PI + HALF_PI-.5, OPEN);
  noFill();
  stroke(50,100,150,100);
  strokeWeight(20);
  line(325,225,400,225);
  stroke(75, 125,175,100);
  line(150,175,400,175);
  stroke(25, 100,125,100);
  line(125,150,400,150);
  stroke(75, 125,175,100);
  line(150,50,400,50);
  stroke(20, 80,100,100);
  line(250,75,400,75);
  stroke(20, 100,100,100);
  line(225,10,400,10);
  stroke(20, 75,100,100);
  line(280,300,400,300);
  
  //ship
  translate(15,-15);
  noStroke();
  //wing right
  fill(100,100,100,100);
  triangle(75,350,100,225,125,355);
  
  //right side
  fill(75,75,75,100);
  quad(75,350,100,225,90,220,65,325);
  
  //fill(125,125,125,100);
  //triangle(100,225,90,220,105,215);
  
  //back
  fill(50,50,50,100);
  quad(75,350,65,325,25,325,15,350);
  
  //top
  fill(80,80,80,100);
  quad(65,325,90,220,50,220,25,325);
  
  //left side
  fill(50,50,50,100);
  quad(15,350,25,325,50,220,45,225);
  
  //left wing
  fill(75,75,75,100);
  triangle(15,350,45,225,-15,355);
  
  //engine
  fill(245,245,255,100);
  ellipse(45,337,30,10);
  
  //engineflare
  noFill();
  strokeWeight(2);
  stroke(250,100,100,100);
  bezier(60,340,50,450,200,400,300,450);
  bezier(30,340,20,450,40,400,75,450);
  
  bezier(50,340,50,450,100,400,50,450);
  bezier(40,340,40,450,50,400,100,450);
  
  fill(200,200,100,100);
  beginShape();
  vertex(40,350);
  vertex(39,380);
  vertex(75,450);
  vertex(32,390);
  vertex(30,340);
  endShape();
  beginShape();
  vertex(60,340);
  vertex(65,380);
  vertex(85,425);
  vertex(55,380);
  vertex(50,350);
  endShape();
  
  strokeWeight(3);
  stroke(200,200,100,100);
  fill(245,245,255,100);
  beginShape();
  vertex(60,337);
  vertex(59,390);
  vertex(100,490);
  vertex(45,390);
  vertex(30,337);
  endShape();
  
  
  //station
  translate(-15,15);
  
  noStroke();
  fill(25,25,25,100);
  arc(300,150,20,100,HALF_PI, PI + HALF_PI);
  fill(75,75,75,100);
  arc(300,150,20,100,PI + HALF_PI, HALF_PI);
  fill(125,125,125,100);
  arc(300,150,20,100,TWO_PI + QUARTER_PI, HALF_PI);
  
  
  stroke(50,50,50, 100);
  fill(125,125,125,100);
  strokeWeight(2);
  
  arc(300,115,100,50,PI - QUARTER_PI, QUARTER_PI );
  fill(10,10,10,100)
  arc(300,115,100,50,PI - QUARTER_PI, -HALF_PI );
  fill(25,25,25,100);
  quad(300,125,300,100,320,120,320,135);
  fill(75,75,75,100);
  quad(300,125,300,100,280,120,280,135);
  fill(100,100,100,100);
  arc(300,100,100,50,PI - QUARTER_PI, QUARTER_PI );
  
}